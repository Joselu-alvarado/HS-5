package examples.bookTrading;

public class Fitnnes {
	Poblacion poblacion;

	public Fitnnes(Poblacion poblacion) {
		this.poblacion = poblacion;
	}

	// Para cada individuo
	public double MSE(double[] b, double[] X, double[] y) {
		double b0 = b[0];
		double b1 = b[1];

		double mse = 0;
		for (int i = 0; i < X.length; i++) {
			double yPred = b0 + b1 * X[i];
			mse += (y[i] - yPred) * (y[i] - yPred);
		}
		return mse / X.length;
	}
}
