package examples.bookTrading;

public class Correlacion {
	private DataSet dataSet;

	public Correlacion() {
		this.dataSet = new DataSet();
	}

	private double calculateCorrelacion() {
		double[] x = dataSet.getX();
		double[] y = dataSet.getY();

		if (x.length != y.length) {
			throw new IllegalArgumentException("Las longitudes de los arreglos x e y deben ser iguales.");
		}

		double sumX = 0.0;
		double sumY = 0.0;
		double sumXY = 0.0;
		double sumXSquare = 0.0;
		double sumYSquare = 0.0;

		for (int i = 0; i < x.length; i++) {
			sumX += x[i];
			sumY += y[i];
			sumXY += x[i] * y[i];
			sumXSquare += x[i] * x[i];
			sumYSquare += y[i] * y[i];
		}

		double numerator = x.length * sumXY - sumX * sumY;
		double denominator = Math.sqrt((x.length * sumXSquare - sumX * sumX) * (x.length * sumYSquare - sumY * sumY));

		return numerator / denominator;
	}

	public double getCorrelacion() {
		return calculateCorrelacion();
	}

	public boolean multipleIndependentVariables() {
		return false;
	}
}
