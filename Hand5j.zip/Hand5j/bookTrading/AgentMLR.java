package examples.bookTrading;

import org.json.JSONArray;
import org.json.JSONObject;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;

public class AgentMLR extends Agent {
    private int[][] features = {
            {23, 26},
            {30, 34},
            {43, 48},
            {52, 57},
            {58, 65}
    };
    private double[] targets = {651, 762, 856, 1063, 1190};
    private MLR mlr;

    protected void setup() {
        System.out.println("Agente " + getLocalName() + " iniciado.");

        registerAgent();

        initializeMLRModel();

        addBehaviour(new RequestHandlingBehaviour());
    }

    private void registerAgent() {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("agentMLR");
        sd.setName("JADE-mlr");
        dfd.addServices(sd);
        try {
            DFService.register(this, dfd);
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }
    }

    private void initializeMLRModel() {
        double[][] X = new double[features.length][features[0].length];
        for (int i = 0; i < features.length; i++) {
            System.arraycopy(features[i], 0, X[i], 0, features[i].length);
        }
        mlr = new MLR(X, targets);
    }

    private class RequestHandlingBehaviour extends CyclicBehaviour {
        private final MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);

        public void action() {
            ACLMessage request = myAgent.receive(template);
            if (request != null) {
                handleRequest(request);
            } else {
                block();
            }
        }

        private void handleRequest(ACLMessage request) {
            myAgent.addBehaviour(new OneShotBehaviour() {
                public void action() {
                    System.out.println("Agente " + getLocalName() + " recibió una solicitud de " + request.getSender().getName());

                    ACLMessage response = request.createReply();
                    boolean willPerformAction = processRequestContent(request.getContent());

                    if (willPerformAction) {
                        response.setPerformative(ACLMessage.AGREE);
                        response.setContent(predict());
                    } else {
                        response.setPerformative(ACLMessage.REFUSE);
                        response.setContent("Rechazo realizar la acción.");
                    }

                    myAgent.send(response);
                    myAgent.doDelete();
                }
            });
        }

        private boolean processRequestContent(String content) {
            JSONObject json = new JSONObject(content);
            JSONArray xArray = json.getJSONArray("X");
            JSONArray yArray = json.getJSONArray("Y");

            double[] x = new double[xArray.length()];
            double[] y = new double[yArray.length()];

            for (int i = 0; i < xArray.length(); i++) {
                x[i] = xArray.getDouble(i);
            }
            for (int i = 0; i < yArray.length(); i++) {
                y[i] = yArray.getDouble(i);
            }
            // Aquí puedes poner la lógica para decidir si aceptas o rechazas la solicitud
            return true;
        }
    }

    private String predict() {
        StringBuilder result = new StringBuilder();
        double[] coefficients = mlr.getCoefficients();

        result.append("Coeficientes de la regresión lineal múltiple:\n");
        for (int i = 0; i < coefficients.length; i++) {
            result.append("Coeficiente ").append(i).append(": ").append(coefficients[i]).append("\n");
        }

        int[][] newFeatures = {
                {60, 70},
                {62, 65},
                {55, 60},
                {44, 22},
                {78, 64}
        };

        for (int[] feature : newFeatures) {
            double prediction = mlr.predict(toDoubleArray(feature));
            result.append("Predicción para x = ").append(java.util.Arrays.toString(feature)).append(": ")
