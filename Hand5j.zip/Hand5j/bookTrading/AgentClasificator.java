package examples.bookTrading;

import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.proto.AchieveREInitiator;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import org.json.JSONObject;

import java.util.Date;
import java.util.Random;

public class AgentClasificator extends Agent {
    private AID[] sellerAgents;
    private final Correlacion correlacion = new Correlacion();
    private final DataSet dataSet = new DataSet();

    protected void setup() {
        System.out.println("Agente " + getLocalName() + " iniciado.");
        System.out.println("Correlación inicial: " + correlacion.getCorrelacion());

        addBehaviour(new TickerBehaviour(this, 5000) {
            protected void onTick() {
                conectarConAgentes();
            }
        });
    }

    private void conectarConAgentes() {
        String agenteSeleccionado = seleccionarAgente();
        System.out.println("Intentando conectar con " + agenteSeleccionado);

        DFAgentDescription template = new DFAgentDescription();
        ServiceDescription sd = new ServiceDescription();
        sd.setType(agenteSeleccionado);
        template.addServices(sd);

        try {
            DFAgentDescription[] result = DFService.search(this, template);
            if (result.length > 0) {
                System.out.println("Se encontraron los siguientes agentes:");
                sellerAgents = new AID[result.length];
                for (int i = 0; i < result.length; ++i) {
                    sellerAgents[i] = result[i].getName();
                    System.out.println(sellerAgents[i].getLocalName());
                }
                enviarRequestAAgentes();
            } else {
                System.out.println("No se encontraron agentes.");
            }
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }
    }

    private void enviarRequestAAgentes() {
        ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
        JSONObject json = new JSONObject();
        json.put("X", dataSet.getX());
        json.put("Y", dataSet.getY());
        request.setContent(json.toString());
        request.setConversationId("agent-trade");
        request.setReplyByDate(new Date(System.currentTimeMillis() + 5000));

        for (AID sellerAgent : sellerAgents) {
            request.addReceiver(sellerAgent);
        }

        addBehaviour(new AchieveREInitiator(this, request) {
            protected void handleAgree(ACLMessage agree) {
                System.out.println("Agente " + agree.getSender().getName() + " aceptó realizar la acción solicitada.");
                System.out.println("Mensaje de respuesta: " + agree.getContent());
                doDelete();
            }

            protected void handleRefuse(ACLMessage refuse) {
                System.out.println("Agente " + refuse.getSender().getName() + " rechazó realizar la acción solicitada.");
                doDelete();
            }

            protected void handleInform(ACLMessage inform) {
                System.out.println("Agente " + inform.getSender().getName() + " completó la acción solicitada.");
                System.out.println("Mensaje de respuesta: " + inform.getContent());
                doDelete();
            }
        });
    }

    private String seleccionarAgente() {
        double correlacionValue = correlacion.getCorrelacion();
        if (correlacionValue > 0.8 && !correlacion.multipleIndependentVariables()) {
            return "agentSLR";
        } else if (correlacionValue > 0.5 && correlacion.multipleIndependentVariables()) {
            return "agentMLR";
        } else if (correlacionValue > 0.5) {
            return "agentPR";
        } else {
            return new Random().nextInt(2) == 1 ? "agentAG" : "agentPSO";
        }
    }
}
