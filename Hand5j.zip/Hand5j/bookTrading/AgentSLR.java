package examples.bookTrading;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import org.json.JSONArray;
import org.json.JSONObject;

public class AgentSLR extends Agent {
    private DiscretMath discreteMaths = new DiscretMath();
    private double beta0;
    private double beta1;
    private int[] array = {56, 70, 30, 62, 60};

    protected void setup() {
        System.out.println("Agente " + getLocalName() + " iniciado.");
        registerAgent();
        addBehaviour(new RequestReceiverBehaviour());
    }

    private void registerAgent() {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("agentSLR");
        sd.setName("JADE-book-trading");
        dfd.addServices(sd);
        try {
            DFService.register(this, dfd);
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }
    }

    private class RequestReceiverBehaviour extends CyclicBehaviour {
        private final MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);

        public void action() {
            ACLMessage request = myAgent.receive(template);
            if (request != null) {
                myAgent.addBehaviour(new ProcessRequestBehaviour(request));
            } else {
                block();
            }
        }
    }

    private class ProcessRequestBehaviour extends OneShotBehaviour {
        private ACLMessage request;

        public ProcessRequestBehaviour(ACLMessage request) {
            this.request = request;
        }

        public void action() {
            System.out.println("Agente " + getLocalName() + " recibió una solicitud de " + request.getSender().getName());
            ACLMessage response = request.createReply();
            boolean willPerformAction = processRequestContent(request.getContent());

            if (willPerformAction) {
                response.setPerformative(ACLMessage.AGREE);
                response.setContent(calculateRegression());
            } else {
                response.setPerformative(ACLMessage.REFUSE);
                response.setContent("Rechazo realizar la acción.");
            }

            myAgent.send(response);
            System.out.println("Agente " + getLocalName() + " aceptó realizar la acción solicitada.");
        }

        private boolean processRequestContent(String content) {
            JSONObject json = new JSONObject(content);
            JSONArray xArray = json.getJSONArray("X");
            JSONArray yArray = json.getJSONArray("Y");

            double[] x = new double[xArray.length()];
            double[] y = new double[yArray.length()];

            for (int i = 0; i < xArray.length(); i++) {
                x[i] = xArray.getDouble(i);
            }
            for (int i = 0; i < yArray.length(); i++) {
                y[i] = yArray.getDouble(i);
            }

            calculateCoefficients(x, y);
            return true;
        }
    }

    private void calculateCoefficients(double[] x, double[] y) {
        int n = x.length;
        double sumXY = discreteMaths.sumXY(x, y);
        double sumX = discreteMaths.sumX(x);
        double sumY = discreteMaths.sumY(y);
        double sumX2 = discreteMaths.cuadro_x(x);

        beta1 = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        beta0 = (sumY - beta1 * sumX) / n;
    }

    private String calculateRegression() {
        StringBuilder result = new StringBuilder();
        result.append("B1: ").append(beta1).append(", B0: ").append(beta0).append("\n");
        result.append(predictValues());
        return result.toString();
    }

    private String predictValues() {
        StringBuilder predictions = new StringBuilder();
        for (int i = 0; i < array.length; i++) {
            double vTemp = beta0 + (beta1 * array[i]);
            predictions.append("Predict ").append(array[i]).append(": ").append(vTemp).append("\n");
        }
        return predictions.toString();
    }
}
