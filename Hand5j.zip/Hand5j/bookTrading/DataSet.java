package examples.bookTrading;

public class DataSet {

    private double[] x;
    private double[] y;
    private int n=9;
    public DataSet(){
    	 x = new double[]{1,2,3,4,5,6,7,8,9};
         y = new double[]{3,6,9,12,15,18,21,24,27};
        // x = new double[]{23,26,30,34,43,48,52,57,58};
        // y = new double[]{651,762,856,1063,1190,1298,1421,1440,1518};
         
    }

    public DataSet(double[] x, double[] y) {
        this.x = x;
        this.y = y;
        n =9; 
    }

    public double[] getX() {
        return x;
    }

    public double[] getY() {
        return y;
    }
    public int getLenght() {
    	return n;
    }
}