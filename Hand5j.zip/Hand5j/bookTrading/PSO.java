package examples.bookTrading;

import java.util.Random;

public class PSO {
    private double[][] particles;
    private double[][] velocity;
    private double[][] pBest;
    private double[] gBest;
    private double[] pBestValues;
    private double gBestValue;
    private Random rand = new Random();

    private double[] target;
    private double[] features;
    private int numParticles;
    private int numIterations;
    private int dimensions;
    private double w;
    private double c1;
    private double c2;

    public PSO(double[] features, double[] target, int numParticles, int numIterations, double w, double c1, double c2) {
        this.features = features;
        this.target = target;
        this.numParticles = numParticles;
        this.numIterations = numIterations;
        this.w = w;
        this.c1 = c1;
        this.c2 = c2;
        this.dimensions = 2; // Only two dimensions for B0 and B1

        this.particles = new double[numParticles][dimensions];
        this.velocity = new double[numParticles][dimensions];
        this.pBest = new double[numParticles][dimensions];
        this.pBestValues = new double[numParticles];
        this.gBest = new double[dimensions];
        this.gBestValue = Double.POSITIVE_INFINITY;

        initializeParticles();
    }

    private void initializeParticles() {
        for (int i = 0; i < numParticles; i++) {
            particles[i][0] = 160 + rand.nextDouble() * 20 - 10; // Initialize B0 around 160-170
            particles[i][1] = 25 + rand.nextDouble() * 10 - 5; // Initialize B1 around 20-30
            for (int j = 0; j < dimensions; j++) {
                velocity[i][j] = rand.nextDouble() * 2 - 1; // Velocities in a controlled range [-1, 1]
                pBest[i][j] = particles[i][j];
            }
            pBestValues[i] = evaluate(particles[i]);
            if (pBestValues[i] < gBestValue) {
                gBestValue = pBestValues[i];
                System.arraycopy(pBest[i], 0, gBest, 0, dimensions);
            }
        }
    }

    private double evaluate(double[] particle) {
        double error = 0.0;
        for (int i = 0; i < features.length; i++) {
            double predicted = particle[0] + particle[1] * features[i];
            error += Math.pow(predicted - target[i], 2);
        }
        return error / features.length; // Mean Squared Error
    }

    private double calculateCOD(double[] particle) {
        double ssTotal = 0;
        double ssResidual = 0;
        double mean = 0;
        for (double v : target) {
            mean += v;
        }
        mean /= target.length;

        for (int i = 0; i < features.length; i++) {
            double predicted = particle[0] + particle[1] * features[i];
            ssTotal += Math.pow(target[i] - mean, 2);
            ssResidual += Math.pow(target[i] - predicted, 2);
        }

        return 1 - (ssResidual / ssTotal);
    }

    public boolean optimize() {
        for (int iter = 0; iter < numIterations; iter++) {
            for (int i = 0; i < numParticles; i++) {
                for (int j = 0; j < dimensions; j++) {
                    velocity[i][j] = w * velocity[i][j] + c1 * rand.nextDouble() * (pBest[i][j] - particles[i][j]) + c2 * rand.nextDouble() * (gBest[j] - particles[i][j]);
                    particles[i][j] += velocity[i][j];
                }
                double value = evaluate(particles[i]);
                if (value < pBestValues[i]) {
                    pBestValues[i] = value;
                    System.arraycopy(particles[i], 0, pBest[i], 0, dimensions);
                }
                if (value < gBestValue) {
                    gBestValue = value;
                    System.arraycopy(particles[i], 0, gBest, 0, dimensions);
                }
                if (calculateCOD(gBest) >= 0.90) {
                    return true;
                }
            }
        }
        return false;
    }

    public double[] getBestSolution() {
        return gBest;
    }

    public double getBestValue() {
        return gBestValue;
    }
}
