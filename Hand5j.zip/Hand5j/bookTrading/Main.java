package examples.bookTrading;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;
import jade.wrapper.AgentContainer;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;

public class Main {
    public static void main(String[] args) {
        // Obtener una instancia de Runtime de JADE
        Runtime rt = Runtime.instance();

        // Configuración básica para el perfil de contenedor
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.GUI, "true"); // Activar la GUI
        profile.setParameter(Profile.MAIN_HOST, "localhost");

        // Crear el contenedor principal
        ContainerController mainContainer = rt.createMainContainer(profile);

        try {
            // Inicializar y lanzar el agente SLR
            AgentController agentSLR = mainContainer.createNewAgent("AgentSLR", AgentSLR.class.getName(), null);
            agentSLR.start();
            AgentController agentEnjambre = mainContainer.createNewAgent("AgentEnjambre", AgentEnjambre.class.getName(), null);
            agentEnjambre.start();
            AgentController agentMLR = mainContainer.createNewAgent("AgentMLR", AgentMLR.class.getName(), null);
            agentMLR.start();
            AgentController agentAG = mainContainer.createNewAgent("AgentAlgorimoGeneetico", AgentPR.class.getName(), null);
            agentAG.start();
            AgentController agentPR = mainContainer.createNewAgent("AgentPR", AgentPR.class.getName(), null);
            agentPR.start();
        } catch (StaleProxyException e) {
            e.printStackTrace();
        }
    }
}
