package examples.bookTrading;

public class MLR {
    private double[] coefficients;

    public MLR(double[][] X, double[] y) {
        int n = X.length;
        int p = X[0].length;

        double[][] augmentedMatrix = new double[n][p + 1];
        for (int i = 0; i < n; i++) {
            augmentedMatrix[i][0] = 1.0; // Add the column of 1s for the intercept
            for (int j = 0; j < p; j++) {
                augmentedMatrix[i][j + 1] = X[i][j];
            }
        }

        double[][] XTX = multiplyMatrices(transpose(augmentedMatrix), augmentedMatrix);
        double[] XTy = multiplyMatrixVector(transpose(augmentedMatrix), y);

        this.coefficients = solveGaussian(XTX, XTy);
    }

    public double predict(double[] x) {
        double result = coefficients[0]; // Intercept
        for (int i = 0; i < x.length; i++) {
            result += coefficients[i + 1] * x[i];
        }
        return result;
    }

    public double[] getCoefficients() {
        return coefficients;
    }

    private double[][] transpose(double[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        double[][] transposed = new double[cols][rows];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transposed[j][i] = matrix[i][j];
            }
        }
        return transposed;
    }

    private double[][] multiplyMatrices(double[][] a, double[][] b) {
        int rowsA = a.length;
        int colsA = a[0].length;
        int colsB = b[0].length;
        double[][] result = new double[rowsA][colsB];
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                result[i][j] = 0;
                for (int k = 0; k < colsA; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return result;
    }

    private double[] multiplyMatrixVector(double[][] matrix, double[] vector) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        double[] result = new double[rows];
        for (int i = 0; i < rows; i++) {
            result[i] = 0;
            for (int j = 0; j < cols; j++) {
                result[i] += matrix[i][j] * vector[j];
            }
        }
        return result;
    }

    private double[] solveGaussian(double[][] a, double[] b) {
        int n = b.length;
        for (int i = 0; i < n; i++) {
            // Find the maximum in the i-th column
            int max = i;
            for (int j = i + 1; j < n; j++) {
                if (Math.abs(a[j][i]) > Math.abs(a[max][i])) {
                    max = j;
                }
            }

            // Swap rows in a and b
            double[] temp = a[i];
            a[i] = a[max];
            a[max] = temp;

            double t = b[i];
            b[i] = b[max];
            b[max] = t;

            // Make zero below the pivot rows
            for (int j = i + 1; j < n; j++) {
                double factor = a[j][i] / a[i][i];
                b[j] -= factor * b[i];
                for (int k = i; k < n; k++) {
                    a[j][k] -= factor * a[i][k];
                }
            }
        }

        // Solve Ax = b for A upper triangular
        double[] x = new double[n];
        for (int i = n - 1; i >= 0; i--) {
            double sum = 0;
            for (int j = i + 1; j < n; j++) {
                sum += a[i][j] * x[j];
            }
            x[i] = (b[i] - sum) / a[i][i];
        }
        return x;
    }
}
