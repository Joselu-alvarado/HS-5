import java.util.Random;

public class AgentAlgGenetico {
    private static final int TAM_POBLACION = 100;
    private static final double T_MUTACION = 0.01;
    private static final double T_CRUZAMIENTO = 0.7;
    private static final int NUMERO_GENERACIONES = 1000;

    private Individuo[] poblacion;
    private Random random = new Random();

    public AgentAlgGenetico() {
        poblacion = new Individuo[TAM_POBLACION];
        for (int i = 0; i < TAM_POBLACION; i++) {
            poblacion[i] = new Individuo();
        }
    }

    public void evolucionar() {
        for (int i = 0; i < NUMERO_GENERACIONES; i++) {
            Individuo[] nuevaPoblacion = new Individuo[TAM_POBLACION];

            for (int j = 0; j < TAM_POBLACION; j++) {
                Individuo padre1 = seleccionarPadre();
                Individuo padre2 = seleccionarPadre();

                Individuo hijo = cruzar(padre1, padre2);
                if (random.nextDouble() < T_MUTACION) {
                    hijo.mutar();
                }
                nuevaPoblacion[j] = hijo;
            }
            poblacion = nuevaPoblacion;
        }
    }

    private Individuo seleccionarPadre() {
        int torneo = 5;
        Individuo mejor = poblacion[random.nextInt(TAM_POBLACION)];
        for (int i = 0; i < torneo - 1; i++) {
            Individuo competidor = poblacion[random.nextInt(TAM_POBLACION)];
            if (competidor.getFitness() > mejor.getFitness()) {
                mejor = competidor;
            }
        }
        return mejor;
    }

    private Individuo cruzar(Individuo padre1, Individuo padre2) {
        return random.nextDouble() < T_CRUZAMIENTO ? padre1.cruzar(padre2) : padre1;
    }

    public Individuo getMejorIndividuo() {
        Individuo mejor = poblacion[0];
        for (Individuo ind : poblacion) {
            if (ind.getFitness() > mejor.getFitness()) {
                mejor = ind;
            }
        }
        return mejor;
    }
}
