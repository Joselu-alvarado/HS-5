package examples.bookTrading;

import java.util.Random;

public class Poblacion {
    static final Random rand = new Random();
    private double[][] population; // Define population as a class field

    // Constructor to initialize the population
    public Poblacion(int sizePoblacion) {
        population = new double[sizePoblacion][2]; // Initialize the population matrix

        // Fill the population matrix with random values
        for (int i = 0; i < sizePoblacion; i++) {
            population[i][0] = rand.nextDouble() * 2000 - 1000; // Initialize b0 in a wide range
            population[i][1] = rand.nextDouble() * 100 - 50;   // Initialize b1 in a wide range
        }
    }

    // Method to get the population
    public double[][] getPopulation() {
        return population;
    }

    // Method to set the population
    public void setPopulation(double[][] newPopulation) {
        population = newPopulation;
    }
}
