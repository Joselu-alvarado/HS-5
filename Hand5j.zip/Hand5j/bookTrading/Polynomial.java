package examples.bookTrading;

import java.util.Random;

public class Poblacion {
    private static final Random rand = new Random();
    private double[][] population;

    public Poblacion(int populationSize) {
        population = new double[populationSize][2];

        // Initialize the population matrix with random values
        for (int i = 0; i < populationSize; i++) {
            population[i][0] = rand.nextDouble() * 2000 - 1000; // Initialize b0 in a wide range
            population[i][1] = rand.nextDouble() * 100 - 50;   // Initialize b1 in a wide range
        }
    }

    public double[][] getPopulation() {
        return population;
    }

    public void setPopulation(double[][] newPopulation) {
        population = newPopulation;
    }
}
