package examples.bookTrading;

import java.util.Iterator;
import java.util.Random;

public class AlgoritmoGenetico {

    static Poblacion poblacion;
    Fitnnes fitnnes;
    int MAX_GENERATIONS;
    int STABILITY_THRESHOLD;
    double MUTATION_RATE;
    double[] bestSolution = null;
    private int[] array = {56, 70, 30, 62, 60};
    static final Random rand = new Random();

    public AlgoritmoGenetico(int MAX_GENERATIONS, int STABILITY_THRESHOLD, double MUTATION_RATE, Poblacion poblacion, Fitnnes fitnnes) {
        this.poblacion = poblacion;
        this.fitnnes = fitnnes;
        this.MAX_GENERATIONS = MAX_GENERATIONS;
        this.STABILITY_THRESHOLD = STABILITY_THRESHOLD;
        this.MUTATION_RATE = MUTATION_RATE;
    }

    public String Ag(double x[], double[] y) {
        double bestFitness = Double.MAX_VALUE;
        int generationsSinceImprovement = 0;

        // Algoritmo genético
        for (int gen = 0; gen < MAX_GENERATIONS; gen++) {
            // Evaluación de fitness
            double[] fitnessScores = new double[poblacion.getPopulation().length];
            for (int i = 0; i < poblacion.getPopulation().length; i++) {
                fitnessScores[i] = fitnnes.MSE(poblacion.getPopulation()[i], x, y);
            }

            // Encontrar el mejor individuo en la generación actual
            int bestIndex = 0;
            for (int i = 1; i < poblacion.getPopulation().length; i++) {
                if (fitnessScores[i] < fitnessScores[bestIndex]) {
                    bestIndex = i;
                }
            }

            if (fitnessScores[bestIndex] < bestFitness) {
                bestFitness = fitnessScores[bestIndex];
                bestSolution = poblacion.getPopulation()[bestIndex].clone();
                generationsSinceImprovement = 0;
            } else {
                generationsSinceImprovement++;
            }

            // Verificar criterio de parada basado en estabilidad
            if (generationsSinceImprovement >= STABILITY_THRESHOLD) {
                break;
            }

            // Selección por torneo
            double[][] selectedPopulation = new double[poblacion.getPopulation().length][2];
            for (int i = 0; i < poblacion.getPopulation().length; i++) {
                int selectedIndex = tournamentSelection(fitnessScores);
                selectedPopulation[i] = poblacion.getPopulation()[selectedIndex];
            }

            // Crossover
            double[][] offspring = new double[poblacion.getPopulation().length][2];
            for (int i = 0; i < poblacion.getPopulation().length; i += 2) {
                double[] parent1 = selectedPopulation[i];
                double[] parent2 = selectedPopulation[i + 1];
                int crossoverPoint = rand.nextInt(2);
                offspring[i] = new double[]{parent1[0], parent2[1]};
                offspring[i + 1] = new double[]{parent2[0], parent1[1]};
            }

            // Mutación
            for (int i = 0; i < poblacion.getPopulation().length; i++) {
                if (rand.nextDouble() < MUTATION_RATE) {
                    offspring[i][0] += rand.nextGaussian() * 10; // Ajustar el factor de mutación según sea necesario
                    offspring[i][1] += rand.nextGaussian() * 1; // Ajustar el factor de mutación según sea necesario
                }
            }
            poblacion.setPopulation(selectedPopulation);
        }

        String result = String.format("Mejor solución: b0 = %.5f, b1 = %.5f con fitness = %.5f\n", bestSolution[0], bestSolution[1], bestFitness);
        result += Predics(); // Agregar las predicciones al resultado
        
        return result;
    }

    // Selección por torneo
    public static int tournamentSelection(double[] fitnessScores) {
        int bestIndex = rand.nextInt(poblacion.getPopulation().length);
        int tournamentSize = 5;
        for (int i = 0; i < tournamentSize; i++) {
            int index = rand.nextInt(poblacion.getPopulation().length);
            if (fitnessScores[index] < fitnessScores[bestIndex]) {
                bestIndex = index;
            }
        }
        return bestIndex;
    }

    private String Predics() {
        StringBuilder predictions = new StringBuilder();
        
        for (int i = 0; i < array.length; i++) {
            double vTemp = bestSolution[0] + (bestSolution[1] * array[i]);
            predictions.append(String.format("Predicción para x = %d: %.5f\n", array[i], vTemp));
        }
        
        return predictions.toString();
    }
}