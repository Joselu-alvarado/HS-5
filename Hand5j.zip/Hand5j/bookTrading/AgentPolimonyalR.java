package examples.bookTrading;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import org.json.JSONArray;
import org.json.JSONObject;

public class AgentPolimonyalR extends Agent {
    private int degree = 1;
    private int n;
    private int[] array = {56, 70, 30, 62, 60};
    private Polynomial pL;

    protected void setup() {
        System.out.println("Agente " + getLocalName() + " iniciado.");
        registerAgent();
        addBehaviour(new RequestHandlingBehaviour());
    }

    private void registerAgent() {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("agentPR");
        sd.setName("JADE-book-trading");
        dfd.addServices(sd);
        try {
            DFService.register(this, dfd);
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }
    }

    private class RequestHandlingBehaviour extends CyclicBehaviour {
        private final MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);

        public void action() {
            ACLMessage request = myAgent.receive(template);
            if (request != null) {
                handleRequest(request);
            } else {
                block();
            }
        }

        private void handleRequest(ACLMessage request) {
            myAgent.addBehaviour(new OneShotBehaviour() {
                public void action() {
                    System.out.println("Agente " + getLocalName() + " recibió una solicitud de " + request.getSender().getName());
                    ACLMessage response = request.createReply();

                    boolean willPerformAction = processRequestContent(request.getContent());

                    if (willPerformAction) {
                        response.setPerformative(ACLMessage.AGREE);
                        response.setContent(predictPolynomial());
                    } else {
                        response.setPerformative(ACLMessage.REFUSE);
                        response.setContent("Rechazo realizar la acción.");
                    }

                    myAgent.send(response);
                    myAgent.doDelete();
                }
            });
        }

        private boolean processRequestContent(String content) {
            JSONObject json = new JSONObject(content);
            JSONArray xArray = json.getJSONArray("X");
            JSONArray yArray = json.getJSONArray("Y");

            double[] x = new double[xArray.length()];
            double[] y = new double[yArray.length()];

            for (int i = 0; i < xArray.length(); i++) {
                x[i] = xArray.getDouble(i);
            }
            for (int i = 0; i < yArray.length(); i++) {
                y[i] = yArray.getDouble(i);
            }

            n = xArray.length();
            pL = new Polynomial(x, y, degree);
            return true;
        }
    }

    private String predictPolynomial() {
        StringBuilder result = new StringBuilder();
        double[] coefficients = pL.getCoefficients();

        for (int i = 0; i <= degree; i++) {
            result.append("Coeficiente para x^").append(i).append(": ").append(coefficients[i]).append("\n");
        }

        for (int x : array) {
            double prediction = pL.predict(x);
            result.append("Predicción para y = ").append(x).append(": ").append(prediction).append("\n");
        }

        return result.toString();
    }
}
