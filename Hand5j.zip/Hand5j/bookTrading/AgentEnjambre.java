package examples.bookTrading;

import org.json.JSONArray;
import org.json.JSONObject;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;

public class AgentEnjambre extends Agent {
    private PSO pso;
    private final int[] array = {56, 70, 30, 62, 60};

    protected void setup() {
        System.out.println("Agente " + getLocalName() + " iniciado.");

        registrarAgente();
        addBehaviour(new CyclicBehaviour() {
            public void action() {
                MessageTemplate template = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
                ACLMessage request = myAgent.receive(template);
                if (request != null) {
                    myAgent.addBehaviour(new ProcesarSolicitudBehaviour(request));
                } else {
                    block();
                }
            }
        });
    }

    private void registrarAgente() {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("agentPSO");
        sd.setName("JADE-PSO");
        dfd.addServices(sd);
        try {
            DFService.register(this, dfd);
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }
    }

    private class ProcesarSolicitudBehaviour extends OneShotBehaviour {
        private final ACLMessage request;

        ProcesarSolicitudBehaviour(ACLMessage request) {
            this.request = request;
        }

        public void action() {
            System.out.println("Agente " + getLocalName() + " recibió una solicitud de " + request.getSender().getName());

            ACLMessage response = request.createReply();
            String content = request.getContent();
            JSONObject json = new JSONObject(content);
            double[] x = jsonArrayToDoubleArray(json.getJSONArray("X"));
            double[] y = jsonArrayToDoubleArray(json.getJSONArray("Y"));

            // Ajustar parámetros: aumentar iteraciones, partículas y ajustar w, c1, c2
            pso = new PSO(x, y, 100, 5000, 0.4, 1.7, 1.7);

            boolean success = pso.optimize();
            if (success) {
                response.setPerformative(ACLMessage.INFORM);
                response.setContent(getOptimizationResult());
            } else {
                response.setPerformative(ACLMessage.FAILURE);
                response.setContent("No se encontró una solución óptima.");
            }

            myAgent.send(response);
        }
    }

    private double[] jsonArrayToDoubleArray(JSONArray jsonArray) {
        double[] doubleArray = new double[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            doubleArray[i] = jsonArray.getDouble(i);
        }
        return doubleArray;
    }

    private String getOptimizationResult() {
        StringBuilder result = new StringBuilder();
        double[] bestSolution = pso.getBestSolution();

        result.append("Mejor solución:\n");
        result.append("B0: ").append(bestSolution[0]).append("\n");
        result.append("B1: ").append(bestSolution[1]).append("\n");
        result.append("Error: ").append(pso.getBestValue()).append("\n");
        result.append(getPredictions(bestSolution));

        return result.toString();
    }

    private String getPredictions(double[] bestSolution) {
        StringBuilder predictions = new StringBuilder();
        for (int value : array) {
            double prediction = bestSolution[0] + (bestSolution[1] * value);
            predictions.append("Predict ").append(value).append(": ").append(prediction).append("\n");
        }
        return predictions.toString();
    }
}
